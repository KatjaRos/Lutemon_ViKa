package com.example.lutemon_vika;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class LutemonViewHolder extends RecyclerView.ViewHolder {
    TextView lut_name, lut_type, attack, defence, color;
    public LutemonViewHolder(@NonNull View itemView) {
        super(itemView);
        lut_name = itemView.findViewById(R.id.lut_name);
        lut_type = itemView.findViewById(R.id.type_lut);
        attack = itemView.findViewById(R.id.xp_attack);
        defence = itemView.findViewById(R.id.xp_defence);
        color = itemView.findViewById(R.id.lut_color);

    }
}
