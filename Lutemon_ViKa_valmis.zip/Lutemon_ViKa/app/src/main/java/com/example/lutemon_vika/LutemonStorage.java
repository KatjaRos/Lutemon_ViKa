package com.example.lutemon_vika;

import android.content.Context;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class LutemonStorage {

    public ArrayList<Lutemon> lutemons = new ArrayList<>();
    private static LutemonStorage storage=null;
    private LutemonStorage(){}

    public void addLutemon(Lutemon lutemon){
        lutemons.add(lutemon);
    }
    public static LutemonStorage getInstance(){
        if(storage == null){
            storage = new LutemonStorage();
        }
        return storage;
    }

    public ArrayList<Lutemon> getLutemons() {return lutemons;}
    public void saveLutemons(Context context){
        try {
            ObjectOutputStream lutemonWriter = new ObjectOutputStream(context.openFileOutput("lutemons.data", Context.MODE_PRIVATE));
            lutemonWriter.writeObject(lutemons);
            lutemonWriter.close();
        } catch (IOException e) {
            System.out.println("Lutemonien tallentaminen epäonnistui");
        }
    }
    public void loadLutemons(Context context){
        try{
            ObjectInputStream lutemonReader = new ObjectInputStream(context.openFileInput("lutemons.data"));
            lutemons = (ArrayList<Lutemon>) lutemonReader.readObject();
            lutemonReader.close();
        } catch (IOException e) {
            System.out.println("Lutemonien lukeminen epäonnistui");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Lutemonien lukeminen2 epäonnistui");
            e.printStackTrace();
        }
    }

}


