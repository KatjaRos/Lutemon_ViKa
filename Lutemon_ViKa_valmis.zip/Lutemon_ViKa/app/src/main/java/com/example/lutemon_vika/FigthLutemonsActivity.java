package com.example.lutemon_vika;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;

public class FigthLutemonsActivity extends AppCompatActivity {
    private Context context;
    public ArrayList<Lutemon> figthers = new ArrayList<>();
    int health1, health2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_figth_lutemons);
        makeRadioButtons1(); makeRadioButtons2();
    }
    public void makeRadioButtons1(){
        RadioGroup lutemonToFigth1 = findViewById(R.id.lutemonToFigth1);
        ArrayList<Lutemon> lutemons = LutemonStorage.getInstance().getLutemons();
        RadioButton rb;
        int i = 0;
        for (Lutemon l : lutemons){
            rb = new RadioButton(this);
            rb.setText(l.getName() +" "+ l.getHealth());
            rb.setId(i++);
            lutemonToFigth1.addView(rb);
        }

    }
    public void makeRadioButtons2(){
        RadioGroup lutemonToFigth2 = findViewById(R.id.lutemonToFigth2);
        ArrayList<Lutemon> lutemons = LutemonStorage.getInstance().getLutemons();
        RadioButton rb;
        int i = 0;
        for (Lutemon l : lutemons){
            rb = new RadioButton(this);
            rb.setText(l.getName() +" "+ l.getHealth());
            rb.setId(i++);
            lutemonToFigth2.addView(rb);
        }

    }
    public void addFigther1 (View view){
        RadioGroup lutemon1 = findViewById(R.id.lutemonToFigth1);
        Lutemon lutemonToFigth1 = LutemonStorage.getInstance().getLutemons().get(lutemon1.getCheckedRadioButtonId());
        figthers.add(lutemonToFigth1);

    }

    public void addFigther2 (View view){
        RadioGroup lutemon2 = findViewById(R.id.lutemonToFigth2);
        Lutemon lutemonToFigth2 = LutemonStorage.getInstance().getLutemons().get(lutemon2.getCheckedRadioButtonId());
        figthers.add(lutemonToFigth2);
    }

    public void startTheFigth (View view){
        ArrayList<Lutemon> lutemons = LutemonStorage.getInstance().getLutemons();
        TextView showTheFigth = findViewById(R.id.showTheFigth);
        showTheFigth.setText("Aloitetaan");
        do  {
        if (figthers.get(0).getAttack()> figthers.get(1).getAttack()){
            showTheFigth.setText(String.valueOf(figthers.get(0).getName()+" ("+ figthers.get(0).getAttack()+ ") aloittaa hyökkäyksen."));
            int i = 0;
            while (lutemons.size() != 0) {
                if (lutemons.get(i).getName() == figthers.get(0).getName()) {
                    health1 = figthers.get(0).getDefense() - figthers.get(1).getAttack();
                    i++;
                }}}
            else {
                    showTheFigth.setText(String.valueOf(figthers.get(1).getName() + " (" + figthers.get(1).getAttack() + ") aloittaa hyökkäyksen."));
                    int j = 0;
                    while (lutemons.size() != 0) {
                        if (lutemons.get(j).getName() == figthers.get(1).getName()) {
                            health2 = figthers.get(1).getDefense() - figthers.get(0).getAttack();
                            j++;
                        }}
                }}
        while ((figthers.get(0).getHealth() != 0 || figthers.get(1).getHealth() != 0)) ;
            }
}