package com.example.lutemon_vika;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);

    }
    public void switchToCreateNewLutemon(View view) {
        Intent intent = new Intent(this, CreateNewLutemon.class);
        startActivity(intent);
    }
    public void switchToListLutemonsActivity(View view) {
        context = this;
        LutemonStorage.getInstance().loadLutemons(context);
        Intent intent = new Intent(this, ListLutemonsActivity.class);
        startActivity(intent);
    }
    public void switchToTrainLutemon(View view) {
        context = this;
        LutemonStorage.getInstance().loadLutemons(context);
        Intent intent = new Intent(this, TrainLutemonsActivity.class);
        startActivity(intent);
    }
    public void switchToFigthLutemons(View view) {
        context = this;
        LutemonStorage.getInstance().loadLutemons(context);
        Intent intent = new Intent(this, FigthLutemonsActivity.class);
        startActivity(intent);
    }


}