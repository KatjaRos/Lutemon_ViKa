package com.example.lutemon_vika;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;

public class CreateNewLutemon extends AppCompatActivity {
    private Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_lutemon);
        context = this;
        showLutemons();

    }
    public void showLutemons(){
        EditText showLutemons = findViewById(R.id.showLutemonTypes);
        showLutemons.setText("Mossmon, defence: 8xp, attack: 20xp\n\nRedimon, defence 17xp, attack 13xp\n\nOranmon, defence 15xp, attack 10xp\n\nBlumon, defence 20xp, attack 8xp");
    }
    public void addLutemon(View view){

        RadioGroup lut_type = findViewById(R.id.lutemon_type);
        EditText nameLutemon = findViewById(R.id.lutemonName);
        String name = nameLutemon.getText().toString();
        String l_type = null;

        switch (lut_type.getCheckedRadioButtonId()) {
            case R.id.btnMossmon:
            l_type = "Mossmon";
            break;
            case R.id.btnBlumon:
            l_type = "Blumon";
            break;
            case R.id.btnRedimon:
            l_type = "Redimon";
            break;
            case R.id.btnOranmon:
            l_type = "Oranmon";
            break;
        }
        LutemonStorage.getInstance().addLutemon(new Lutemon(name,l_type));
        LutemonStorage.getInstance().saveLutemons(context);


        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}