package com.example.lutemon_vika;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LutemonViewAdapter extends RecyclerView.Adapter<LutemonViewHolder> {

    private Context context;
    private ArrayList<Lutemon> lutemons = new ArrayList<>();


    public LutemonViewAdapter(Context context, ArrayList<Lutemon> lutemons) {
        this.context = context;
        this.lutemons = lutemons;

    }
    @NonNull
    @Override
    public LutemonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LutemonViewHolder(LayoutInflater.from(context).inflate(R.layout.lutemon_view,parent,false ));
    }

    @Override
    public void onBindViewHolder(@NonNull LutemonViewHolder holder, int position) {
        holder.lut_name.setText(lutemons.get(position).getName());
        holder.lut_type.setText(lutemons.get(position).getType());
        holder.attack.setText(String.valueOf(lutemons.get(position).getAttack()) + "xp");
        holder.defence.setText(String.valueOf(lutemons.get(position).getDefense())+"xp");
        holder.color.setText(lutemons.get(position).getColor());
    }



    @Override
    public int getItemCount() {
        return lutemons.size();
    }
}
